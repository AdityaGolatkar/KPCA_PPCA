g++ createfile.cpp -o cf
./cf<no.txt>create.sh