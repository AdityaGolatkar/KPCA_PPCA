gedit 1.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/1.png -e
pkill gedit
gedit 2.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/2.png -e
pkill gedit
gedit 3.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/3.png -e
pkill gedit
gedit 4.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/4.png -e
pkill gedit
gedit 5.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/5.png -e
pkill gedit
gedit 6.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/6.png -e
pkill gedit
gedit 7.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/7.png -e
pkill gedit
gedit 8.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/8.png -e
pkill gedit
gedit 9.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/9.png -e
pkill gedit
gedit 10.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/10.png -e
pkill gedit
gedit 11.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/11.png -e
pkill gedit
gedit 12.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/12.png -e
pkill gedit
gedit 13.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/13.png -e
pkill gedit
gedit 14.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/14.png -e
pkill gedit
gedit 15.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/15.png -e
pkill gedit
gedit 16.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/16.png -e
pkill gedit
gedit 17.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/17.png -e
pkill gedit
gedit 18.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/18.png -e
pkill gedit
gedit 19.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/19.png -e
pkill gedit
gedit 20.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/20.png -e
pkill gedit
gedit 21.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/21.png -e
pkill gedit
gedit 22.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/22.png -e
pkill gedit
gedit 23.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/23.png -e
pkill gedit
gedit 24.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/24.png -e
pkill gedit
gedit 25.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/25.png -e
pkill gedit
gedit 26.txt & disown
shutter -s=245,460,150,150 -o ~/code/images/26.png -e
pkill gedit
