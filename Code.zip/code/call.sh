cp create.cpp screenshot.cpp files/
cd files
g++ create.cpp -o cr
./cr<input.txt
g++ screenshot.cpp -o sc
./sc>main.sh